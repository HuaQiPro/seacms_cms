﻿eval(function(p,a,c,k,e,r){e=function(c){return(c<62?'':e(parseInt(c/62)))+((c=c%62)>35?String.fromCharCode(c+29):c.toString(36))};if('0'.replace(0,e)==0){while(c--)r[e(c)]=k[c];k=[function(e){return r[e]||e}];e=function(){return'([679a-fh-wyzQ-WYZ]|1\\w)'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 v(G){a K=[],$=e,L=v.14||(v.14=[]);(6(E){a D=6(){};E=E?E:{};a C=["k","w","l","j","m","15","16","17","y","z","Q"],A=["","","n",i,I("GBK"),3600000,D,D,D,D,D],B=C.c;R(B--)$[C[B]]=_(E[C[B]],A[B]);9(!N())7 b})(G);6 _(_,$){7 _!=undefined?_:$}6 N(){a A,$=[window.S,"MSXML2.18","Microsoft.18"];o(a B=0;B<L.c;B+=1)9(L[B].T==0||L[B].T==4)7 L[B];o(B=0;B<$.c;B+=1){U{A=($[B]&&p($[B])=="6"?q $[B]:q ActiveXObject($[B]));V}W(_){A=b;continue}}9(!A){19"Cannot init S object!";7 b}d{L[L.c]=A;7 A}}6 E($){7 1a.getElementById($)}6 C($){a _=$*1;7(isNaN(_)?0:_)}6 D($){7(p($)=="1b"?($=E($))?$:b:$)}6 F(){7((q Date)*1)}6 M($,_){K[$+""]=_}6 H($){7(K[$+""])}6 J(_,$,B){7(6 A(C){C=C.r(/([^\\1c-\\1d]+)/g,6($0,$1){7 _($1)}).r(/([\\1c-\\1d])/g,6($0,$1){7 1e($1).r("%","%u00")});o(a E=0,D=$.c;E<D;E+=1)C=C.r($[E],B[E]);7(C)})}6 I($){9($.s()=="UTF-8")7(encodeURIComponent);d 7(J(1e,[/\\+/g],["%2B"]))}6 O(A,B){9(!A.Y)7;a _="|"+A.Y.s()+"|";9("|INPUT|TEXTAREA|OPTION|".Z(_)>-1)A.t=B;d{U{A.innerHTML=B}W($){}}}6 P(_){9(p(_)=="6")7 _;d{_=D(_);9(_)7(6($){O(_,$.responseText)});d 7 $.z}}6 B(_,A,$){a C=0,B=[];R(C<_.c){B[C]=_[C]?($[C]?$[C](_[C]):_[C]):A[C];C+=1}R(C<A.c){B[C]=A[C];C+=1}7 B}6 A(){a E,C=b,K=N(),J=B(10,[$.k,$.w,$.z,$.l,$.j,f],[f,f,P,f,f,f]),G=J[0],I=J[1],L=J[2],M=J[3],H=J[4],A=J[5],O=M.s()=="u"?i:b;9(!G){19"k is f";7 b}a _={k:G,w:I,l:M,params:A};9(!O)G+=(G.Z("?")>-1?"&":"?")+"timestamp="+F();K.open(M,G,H);$.17(_);9(O)K.1f("Content-Type","application/x-www-form-urlencoded");K.1f("X-Request-With","S");E=1g(6(){C=i;K.abort()},$.15);a D=6(){9(C){$.16(_);$.y(_)}d 9(K.T==4){1h(E);_.11=K.11;U{9(K.11==200)L(K,A);d $.Q(_)}W(B){$.Q(_)}$.y(_)}};K.onreadystatechange=D;9(O)K.1i(I);d K.1i("");9(H==b)D();7 i}e.setcharset=6(_){9(!$.m)$.m=I(_)};e._1ll1=6(1j){1a.write(1j)};e.get=6(C,B,_){7 A(C,"",B,"n",$.j,_)};e.update=6(H,J,_,D,E){_=C(_);D=C(D);9(_<1)D=1;a B=6(){A(J,"",H,"n",$.j,E)},G=F(),I=6($){B();$--;9($>0)M(G,1g(6(){I($)},_))};I(D);7 G};e.stopupdate=6($){1h(H($))};e.post=6(D,_,C,B){7 A(D,_,C,"u",$.j,B)};e.postf=6(O,J,B){a H=[],L,_,G,I,M,K=10.c,C=10;O=O?D(O):b;9(!O||O.Y!="FORM")7 b;h=O.12("onvalidate");h=h?(p(h)=="1b"?q Function(h):h):f;9(h&&!h())7 b;a E=O.12("action"),N=O.12("l"),F=$.1k(O);9(F.c==0)7 b;9(N.s()=="u")7 A(E,F,J,"u",i,B);d{E+=(E.Z("?")>-1?"&":"?")+F;7 A(E,"",J,"n",i,B)}};e.1k=6(C){a B="",E="",_,A;o(a D=0;D<C.c;D+=1){_=C[D];9(_.1l!=""){switch(_.type){13"select-one":9(_.1m>-1)A=_.options[_.1m].t;d A="";V;13"checkbox":13"radio":9(_.checked==i)A=_.t;V;default:A=_.t}A=$.m(A);B+=E+_.1l+"="+A;E="&"}}7 B}}',[],85,'||||||function|return||if|var|false|length|else|this|null||validfoo|true|async|url|method|encode|GET|for|typeof|new|replace|toUpperCase|value|POST|AJAX|content||onrequestend|oncomplete|||||||||||||||||onexception|while|XMLHttpRequest|readyState|try|break|catch||nodeName|indexOf|arguments|status|getAttribute|case|__pool__|timeout|ontimeout|onrequeststart|XMLHTTP|throw|document|string|u0080|u00FF|escape|setRequestHeader|setTimeout|clearTimeout|send|str|formToStr|name|selectedIndex'.split('|'),0,{}));eval(function(p,a,c,k,e,r){e=function(c){return c.toString(36)};if('0'.replace(0,e)==0){while(c--)r[e(c)]=k[c];k=[function(e){return r[e]||e}];e=function(){return'[1-9a-fhj-ru-y]'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('2 $(7){a 4.getElementById(7)}2 checkAll(o,c,5){3 1;1=f(c,5);h(3 i=0;i<1.d;i++){1[i].b=o}}2 checkOthers(c,5){3 1;1=f(c,5);h(3 i=0;i<1.d;i++){6(1[i].b==p){1[i].b=q}r 6(1[i].b==q){1[i].b=p}}}2 textareasize(8){6(8.u>70){8.j.height=8.u+\'px\'}}2 set(8,v){8.innerHTML=v}2 view(7){$(7).j.w=\'inline\'}2 hide(7){$(7).j.w=\'none\'}2 getScroll(){3 t;6(4.k&&4.k.l){t=4.k.l}r 6(4.x){t=4.x.l}a(t)}2 HtmlEncode(m){3 s="";6(m.d==0)a"";s=m.9(/&/g,"&amp;");s=s.9(/</g,"&lt;");s=s.9(/>/g,"&gt;");s=s.9(/ /g,"&nbsp;");s=s.9(/\\\'/g,"&#39;");s=s.9(/\\"/g,"&quot;");a s}2 f(y,5){3 n=new Array();3 e=4.getElementsByTagName(y);h(3 i=0;i<e.d;i++){6(e[i].5==5)n.push(e[i])}a n}',[],35,'|checkboxArray|function|var|document|name|if|id|obj|replace|return|checked|tagname|length|el|getElementsByName||for||style|documentElement|scrollTop|str|rtArr|bool|false|true|else|||scrollHeight|value|display|body|tag'.split('|'),0,{}))

function closeWin(){
	document.body.removeChild($("bg")); 
	document.body.removeChild($("msg"));
	if($("searchtype"))document.getElementById("searchtype").style.display="";
}

function openWindow(zindex,width,height,alpha){
	var iWidth = document.documentElement.scrollWidth; 
	var iHeight = document.documentElement.clientHeight; 
	var bgDiv = document.createElement("div");
	bgDiv.id="bg";
	bgDiv.style.cssText = "top:0;width:"+iWidth+"px;height:"+document.documentElement.scrollHeight+"px;filter:Alpha(Opacity="+alpha+");opacity:0.3;z-index:"+zindex+";";
	document.body.appendChild(bgDiv); 
	var msgDiv=document.createElement("div");
	msgDiv.id="msg";
	msgDiv.style.cssText ="z-index:"+(zindex+1)+";width:"+width+"px; height:"+(parseInt(height)-0+29+16)+"px;left:"+((iWidth-width-2)/2)+"px;top:"+(getScroll()+(height=="auto"?150:(iHeight>(parseInt(height)+29+2+16+30)?(iHeight-height-2-29-16-30)/2:0)))+"px";
	msgDiv.innerHTML="<div class='msgtitle'><div id='msgtitle'></div><img onclick='closeWin()' src='/"+sitePath+"pic/btn_close.gif' /></div><div id='msgbody' style='height:"+height+"px'></div>";
	document.body.appendChild(msgDiv);
}

function openWindow2(zindex,width,height,alpha){
	var iWidth = document.documentElement.scrollWidth; 
	var bgDiv = document.createElement("div");
	bgDiv.id="bg";
	bgDiv.style.cssText = "top:0;width:"+iWidth+"px;height:"+document.documentElement.scrollHeight+"px;filter:Alpha(Opacity="+alpha+");opacity:0.3;z-index:"+zindex+";";
	document.body.appendChild(bgDiv); 
	var msgDiv=document.createElement("div");
	msgDiv.id="msg";
	msgDiv.style.cssText ="position: absolute;z-index:"+(zindex+1)+";width:"+width+"px; height:"+(height=="auto"?height:(height+"px"))+";";
	document.body.appendChild(msgDiv);	
}

function selectTogg(){
	var selects=document.getElementsByTagName("select");
	for(var i=0;i<selects.length;i++){
		selects[i].style.display=(selects[i].style.display=="none"?"":"none");
	}
}
function checkInput(str,type){
	switch(type){
		case "mail":
			if(!/^([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/gi.test(str)){alert('邮箱填写错误');return false;}
			break;
		case "num" :
			if(isNaN(str)){alert('QQ填写错误');return false;}
			break;
	}
	return true;
}

function copyToClipboard(txt) {    
	if(window.clipboardData){    
		window.clipboardData.clearData();    
		window.clipboardData.setData("Text", txt);
		alert('复制成功！')
	}else{
		alert('请手动复制！')	
	}   
}
function   getUrlArgs()   
  {   
     return  location.pathname;
  }


//