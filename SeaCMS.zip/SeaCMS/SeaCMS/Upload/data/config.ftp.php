<?php 
$app_ftp = '0';
$app_ftphost = 'test.seacms.org';
$app_ftpuser = 'seacmstest';
$app_ftppass = 'seacmstest';
$app_ftpport = '21';
$app_ftpdir = '/';
$app_ftpurl = 'http://test.seacms.org';
$app_ftpdel = '0';
$app_updatepic = '0';
?>