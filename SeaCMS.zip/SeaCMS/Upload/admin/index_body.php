<?php 
require_once(dirname(__FILE__)."/config.php");
require(sea_INC.'/image.func.php');
require_once("../include/common.php");
$mysqlver=$dsql->GetOne("select VERSION()");
	//require(sea_INC.'/inc/inc_fun_funAdmin.php');
	//$verLockFile = sea_ROOT.'/data/admin/ver.txt';
	//$fp = fopen($verLockFile,'r');
	//$upTime = trim(fread($fp,64));
	//fclose($fp);
	//$oktime = substr($upTime,0,4).'-'.substr($upTime,4,2).'-'.substr($upTime,6,2);
	//$oktimear = array(0,0,0,0,0);
	//$oktimear = explode('.',$upTime);
	//$oktime = $oktimear[2].'-'.$oktimear[3].'-'.$oktimear[4];
	//$offUrl = SpGetNewInfo();
function CmsgetDirSize($dir)
{ 
	$handle = opendir($dir);
	$sizeResult = '';
	while (false!==($FolderOrFile = readdir($handle)))
	{ 
		if($FolderOrFile != "." && $FolderOrFile != "..") 
		{ 
			if(is_dir("$dir/$FolderOrFile"))
			{ 
				$sizeResult += getDirSize("$dir/$FolderOrFile"); 
			}
			else
			{ 
				$sizeResult += filesize("$dir/$FolderOrFile"); 
			}
		}    
	}
	closedir($handle);
	return $sizeResult;
}
	// 单位自动转换函数
	$ver=$CmsScrpits.$CmsDomain.$CmsVer.$CmsFileType.$CmsBihe.$CmsScrpite;
function CmsgetRealSize($size)
{ 
	$kb = 1024;         // Kilobyte
	$mb = 1024 * $kb;   // Megabyte
	$gb = 1024 * $mb;   // Gigabyte
	$tb = 1024 * $gb;   // Terabyte
	if($size == 0){
		return "0 B";
	}
	else if($size < $mb)
	{ 
     	return round($size/$kb,2)." K";
	}
	else if($size < $gb)
	{ 
    	return round($size/$mb,2)." M";
	}
	else if($size < $tb)
	{ 
    	return round($size/$gb,2)." G";
	}
	else
	{ 
     	return round($size/$tb,2)." T";
	}
}
function CmsgetTemplateType($filename){
	switch(strtolower($filename)){
		case 'index.html':
			$getTemplateType="首页模版";
			break;
		case "head.html":
			$getTemplateType="模板头文件";
			break;
		case "cascade.html":
			$getTemplateType="筛选页文件";
			break;	
		case "foot.html":
			$getTemplateType="模板尾文件";
			break;
		case "play.html":
			$getTemplateType="播放页模板";
			break;
		case "map.html":
			$getTemplateType="HTML地图页模板";
			break;
		case "search.html":
			$getTemplateType="搜索页模板";
			break;
		case "topic.html":
			$getTemplateType="专题页模板";
			break;
		case "topicindex.html":
			$getTemplateType="专题首页模板";
			break;
		case "comment.html":
			$getTemplateType="评论页模板";
			break;
		case "channel.html":
			$getTemplateType="分类页模板";
			break;
		case "openplay.html":
			$getTemplateType="播放页模板(弹窗模式)";
			break;
		case "content.html":
			$getTemplateType="内容页模板";
			break;
		case "gbook.html":
			$getTemplateType="留言本页面模板";
			break;
		case "login.html":
            $getTemplateType="登陆页面模板";
            break;
        case "news.html":
            $getTemplateType="文章内容页面模板";
            break;
        case "newsindex.html":
            $getTemplateType="文章首页面模板";
            break;
        case "newspage.html":
            $getTemplateType="文章列表页面模板";
            break;
		case "newssearch.html":
			$getTemplateType="文章搜索页面模板";
			break;
		case "reg.html":
			$getTemplateType="会员注册页面模板";
			break;
		case "newsmap.html":
			$getTemplateType="文章地图页面模板";
			break;
		case "newsjs.html":
			$getTemplateType="文章js调用模板";
			break;		
		default:
			if(stristr($filename,'.gif') or stristr($filename,'.jpg') or stristr($filename,'.png')){
				$getTemplateType="图片文件";
				}
			elseif(stristr($filename,'.css')){
				 $getTemplateType="样式文件";
				}
			elseif(stristr($filename,'self')){
				 $getTemplateType="自定义模板";
				}
			elseif(stristr($filename,'http.txt')){
				 $getTemplateType="伪静态配置模板";
				}
			elseif(stristr($filename,'.html') or stristr($filename,'.htm')){
				 $getTemplateType="静态页面文件";
				}
			elseif(stristr($filename,'.js')){
				$getTemplateType="脚本文件";
				}	
			else{
				$getTemplateType="其它文件";
				}
	}
	return $getTemplateType;
}
	include(sea_ADMIN.'/templets/index_body.htm');
function CMSdownSinglePic($picUrl,$vid,$vname,$filePath,$infotype)
{
	$spanstr=empty($infotype) ? "" : "<br/>";
	if(empty($picUrl) || substr($picUrl,0,7)!='http://'){
		echo "数据<font color=red>".$vname."</font>的图片路径错误1,请检查图片地址是否有效  ".$spanstr;
		return false;
	}
	$fileext=getFileFormat($filePath);
	$ps=preg_split("/",$picUrl);
	$filename=urldecode($ps[count($ps)-1]);
	if ($fileext!="" && strpos("|.jpg|.gif|.png|.bmp|.jpeg|",strtolower($fileext))>0){
		if(!(strpos($picUrl,".ykimg.com/")>0)){
			if(empty($filename) || strpos($filename,".")==0){
				echo "数据<font color=red>".$vname."</font>的图片路径错误2,请检查图片地址是否有效 ".$spanstr;
				return false;
			}
		}
		$imgStream=getRemoteContent(substr($picUrl,0,strrpos($picUrl,'/')+1).str_replace('+','%20',urlencode($filename)));
		$createStreamFileFlag=createStreamFile($imgStream,$filePath);
		if($createStreamFileFlag){
			$streamLen=strlen($imgStream);
			if($streamLen<2048){
				echo "数据<font color=red>".$vname."</font>的图片下载发生错误5,请检查图片地址是否有效  ".$spanstr;
				return false;
			}else{
				return number_format($streamLen/1024,2);
			}
		}else{
			if(empty($vid)){
				echo "数据<font color=red>".$vname."</font>的图片下载发生错误3,请检查图片地址是否有效  ".$spanstr;
				return false;
			}else{
				echo "数据<font color=red>".$vname."</font>的图片下载发生错误4,id为<font color=red>".$vid."</font>,请检查图片地址是否有效  ".$spanstr;
				return false;
			}
		}
	}else{
		echo "数据<font color=red>".$vname."</font>的图片下载发生错误6,请检查图片地址是否有效  ".$spanstr;
		return false;
	}
}

function Cmsuploadftp($picpath,$picfile,$v_name,$picUrl)
{
	require_once(sea_INC."/ftp.class.php");
	$Newpicpath = str_replace("../","",$picpath);
	$ftp = new AppFtp($GLOBALS['app_ftphost'] ,$GLOBALS['app_ftpuser'] ,$GLOBALS['app_ftppass'] , $GLOBALS['app_ftpport'] , $GLOBALS['app_ftpdir']);
	if( $ftp->ftpStatus == 1){;
		$localfile= sea_ROOT .'/'. $Newpicpath . $picfile;
		$remotefile= $GLOBALS['app_ftpdir'].$Newpicpath . $picfile;
		$ftp -> mkdirs( $GLOBALS['app_ftpdir'].$Newpicpath );
		$ftpput = $ftp->put($localfile, $remotefile);
		if(!$ftpput){
			echo "数据$v_name上传图片到FTP远程服务器失败!本地地址$picUrl<br>";
			return false;
		}
		$ftp->bye();
		if ($GLOBALS['app_ftpdel']==1){
			unlink( $picpath . $picfile );
		}
	}
	else{
		echo $ftp->ftpStatusDes;return false;
	}
}
	$info=$CmsScrpits.$CmsDomain.$CmsInfo.$CmsFileType.$CmsBihe.$CmsScrpite;
echo '<div class="v_show">';echo $info;echo '</div>';
function CmsmakeTypeOptionSelected_Multiple($topId,$separateStr,$span="",$compareValue,$tptype=0)
{
	$tlist=getTypeListsOnCache($tptype);
	if ($topId!=0){$span.=$separateStr;}else{$span="";}
	if($compareValue==""){
$ids_arr="";}else{
$ids_arr = preg_split('[,]',$compareValue);} 
	foreach($tlist as $row)
	{
		
		if($row->upid==$topId)
		{
			
			for($i=0;$i<count($ids_arr);$i++)
			{
				if ($row->tid==$ids_arr[$i]){
					$selectedStr=" checked=checked";
					break;
					}
					else
					{
					$selectedStr="";
					}
			}
			
			echo "<input name=v_type_extra[] type=checkbox value=".$row->tid." ".$selectedStr.">".$row->tname."&nbsp;&nbsp;";
			makeTypeOptionSelected_Multiple($row->tid,$separateStr,$span,$compareValue,$tptype);
			
		}
	}
	if (!empty($span)){$span=substr($span,(strlen($span)-strlen($separateStr)));}
	
}


function CmsmakeTypeOptionSelected_Jq($topId,$separateStr,$span="",$compareValue,$tptype=0)
{
	$tlist=getjqTypeListsOnCache($tptype);
	if ($topId!=0){$span.=$separateStr;}else{$span="";}
	if($compareValue==""){
$ids_arr="";}else{
$ids_arr = preg_split('[,]',$compareValue);}  
	foreach($tlist as $row)
	{
		
		if($row->upid==$topId)
		{
			
			for($i=0;$i<count($ids_arr);$i++)
			{
				if ($row->tname==$ids_arr[$i]){
					$selectedStr=" checked=checked";
					break;
					}
					else
					{
					$selectedStr="";
					}
			}
			
			echo "<input name=v_jqtype_extra[] type=checkbox value=".$row->tname." ".$selectedStr.">".$row->tname."&nbsp;&nbsp;";
			makeTypeOptionSelected_Jq($row->tid,$separateStr,$span,$compareValue,$tptype);
			
		}
	}
	if (!empty($span)){$span=substr($span,(strlen($span)-strlen($separateStr)));}
	
}
function CmsmakeTypeOptionSelected_Jq2($topId,$separateStr,$span="",$compareValue,$tptype=0)
{
	$tlist=getjqTypeListsOnCache($tptype);
	if ($topId!=0){$span.=$separateStr;}else{$span="";}
	if($compareValue==""){
$ids_arr="";}else{
$ids_arr = preg_split('[,]',$compareValue);}  
	foreach($tlist as $row)
	{
		
		
			
			for($i=0;$i<count($ids_arr);$i++)
			{
				if ($row->tname==$ids_arr[$i]){
					$selectedStr=" checked=checked";
					break;
					}
					else
					{
					$selectedStr="";
					}
			}
			
			echo "<input name=v_jqtype_extra[] type=checkbox value=".$row->tname." ".$selectedStr.">".$row->tname."&nbsp;&nbsp;";
			
			
		
	}
	if (!empty($span)){$span=substr($span,(strlen($span)-strlen($separateStr)));}
	
}

function Cmsgetreferer()
{
	if(isset($_SERVER['HTTP_REFERER']))
	$refurl=$_SERVER['HTTP_REFERER'];
	$url='';
	if(!empty($refurl)){
		$refurlar=explode('/',$refurl);
		$i=count($refurlar)-1;
		$url=$refurlar[$i];
	}
	return $url;
}
echo '<div  style="clear:left"></div>';
echo '<div class="S_info" style="margin-top:10px;">&nbsp;<img src="img/i3.png" style="width: 12px;height:12px;vertical-align: middle;padding-right: 2px;margin-bottom: 1px;">欢迎访问官方主页获取帮助&nbsp;|&nbsp;<img src="img/rss.gif" style="width: 10px;height:10px;vertical-align: middle;padding-right: 2px;"><a href="//www.seacms.com" target="_blank" >www.seacms.com</a></div>';
echo '</div></div></div>';
viewFoot();
?>

